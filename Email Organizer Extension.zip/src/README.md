# Gmail Email Organizer Extension

A powerful browser extension that enhances Gmail with advanced email organization, filtering, and management features.

## Features

- **Advanced Email Organization**: Custom folders, labels, and smart categorization
- **Powerful Search & Filtering**: Search across subjects, senders, content, and labels
- **Email Management**: Mark as read/unread, star/unstar, archive, and delete emails
- **Real-time Integration**: Seamlessly integrates with Gmail's interface
- **Responsive Design**: Works on both desktop and mobile Gmail

## Installation

### Development Installation

1. **Clone or download** this project to your local machine

2. **Enable Developer Mode** in Chrome:
   - Open Chrome and go to `chrome://extensions/`
   - Toggle "Developer mode" in the top right corner

3. **Load the Extension**:
   - Click "Load unpacked"
   - Select the folder containing this extension

4. **Open Gmail**:
   - Navigate to [mail.google.com](https://mail.google.com)
   - You should see a floating blue button in the bottom right corner

5. **Start Organizing**:
   - Click the floating button to open the Email Organizer sidebar
   - Use the extension icon in Chrome's toolbar for quick access

### Production Installation

*Coming soon to Chrome Web Store*

## How to Use

### Opening the Organizer
- **Floating Button**: Click the blue email icon in Gmail's bottom right corner
- **Extension Icon**: Click the extension icon in Chrome's toolbar
- **Keyboard Shortcut**: *Coming soon*

### Features Overview

#### Sidebar Navigation
- **Inbox**: View all inbox emails
- **Starred**: Quick access to starred emails
- **Sent**: Review sent emails
- **Drafts**: Continue working on drafts
- **Archive**: Browse archived emails
- **Custom Labels**: Work, Personal, Finance folders

#### Email Management
- **Read/Unread**: Toggle read status with visual indicators
- **Star Emails**: Mark important emails with stars
- **Archive**: Move emails to archive folder
- **Delete**: Send emails to trash
- **Labels**: Organize with custom labels

#### Search & Filter
- **Global Search**: Search across all email content
- **Filter Options**: Filter by read status, date, attachments
- **Label Search**: Find emails by specific labels

#### Email Details
- **Full Content**: Read complete email content
- **Attachments**: Download email attachments
- **Reply Actions**: Reply, Reply All, Forward
- **Quick Actions**: Archive, delete, star from detail view

## Technical Details

### Architecture
- **Content Script**: Integrates with Gmail's DOM
- **Background Script**: Handles extension lifecycle
- **React App**: Modern UI built with React and Tailwind CSS
- **Chrome APIs**: Uses Chrome extension APIs for permissions and storage

### File Structure
```
├── manifest.json          # Extension configuration
├── content.js             # Gmail integration script
├── background.js           # Service worker
├── popup.html/js           # Extension popup
├── extension.css           # Extension-specific styles
├── app-bundle.js           # React app bundle
└── components/             # React components
    ├── EmailSidebar.tsx
    ├── EmailList.tsx
    ├── EmailDetail.tsx
    ├── SearchBar.tsx
    └── GmailIntegration.tsx
```

### Browser Compatibility
- **Chrome**: Full support (Manifest V3)
- **Edge**: Compatible with Chrome extensions
- **Firefox**: *Coming soon* (requires Manifest V2 adaptation)

## Privacy & Security

- **Local Processing**: All email data is processed locally in your browser
- **No Data Collection**: Extension doesn't collect or transmit personal data
- **Gmail Permissions**: Only accesses Gmail when you're actively using it
- **Open Source**: Full source code is available for review

## Development

### Prerequisites
- Node.js 16+ (for development tools)
- Chrome browser with Developer mode enabled

### Setup
```bash
# Install dependencies (optional - for development tools)
npm install

# For development with hot reload
npm run dev

# Build for production
npm run build
```

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly with Gmail
5. Submit a pull request

## Troubleshooting

### Extension Not Working
1. **Refresh Gmail**: Reload the Gmail tab
2. **Check Permissions**: Ensure extension has access to mail.google.com
3. **Update Extension**: Reload the extension in chrome://extensions/
4. **Browser Console**: Check for errors in browser console

### Performance Issues
1. **Email Limit**: Extension processes up to 50 emails for performance
2. **Refresh Rate**: Emails refresh every 5 seconds automatically
3. **Browser Resources**: Close unused tabs to free up memory

### Gmail Compatibility
- Works with new Gmail interface
- Some features may be limited in basic HTML mode
- Mobile Gmail has responsive layout adaptations

## Roadmap

### Version 1.1
- [ ] Keyboard shortcuts
- [ ] Email composition within extension
- [ ] Multiple Gmail account support
- [ ] Export/import email data

### Version 1.2
- [ ] Email templates
- [ ] Scheduled sending
- [ ] Advanced automation rules
- [ ] Dark mode theme

### Version 2.0
- [ ] Outlook integration
- [ ] Team collaboration features
- [ ] AI-powered email categorization
- [ ] Analytics and insights

## Support

- **Issues**: Report bugs on GitHub Issues
- **Feature Requests**: Submit ideas on GitHub Discussions
- **Email**: [Contact developer](mailto:support@example.com)

## License

MIT License - see LICENSE file for details.

---

**Made with ❤️ for Gmail power users**