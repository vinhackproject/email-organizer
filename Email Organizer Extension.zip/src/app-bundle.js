// Gmail Email Organizer - Extension Bundle
// This file initializes the React app within the Gmail extension context

// Initialize the Gmail Organizer React app
window.initGmailOrganizer = function() {
  console.log('Initializing Gmail Organizer...');
  
  // Check if React is already loaded
  if (window.React && window.ReactDOM) {
    initializeApp();
    return;
  }
  
  // Import React and ReactDOM with error handling
  const script = document.createElement('script');
  script.src = 'https://unpkg.com/react@18/umd/react.production.min.js';
  script.crossOrigin = 'anonymous';
  script.onload = function() {
    console.log('React loaded');
    const reactDOMScript = document.createElement('script');
    reactDOMScript.src = 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js';
    reactDOMScript.crossOrigin = 'anonymous';
    reactDOMScript.onload = function() {
      console.log('ReactDOM loaded');
      // Initialize the app
      setTimeout(initializeApp, 100);
    };
    reactDOMScript.onerror = function(error) {
      console.error('Failed to load ReactDOM:', error);
      initializeFallbackApp();
    };
    document.head.appendChild(reactDOMScript);
  };
  script.onerror = function(error) {
    console.error('Failed to load React:', error);
    initializeFallbackApp();
  };
  document.head.appendChild(script);
};

function initializeApp() {
  try {
    console.log('Initializing React app...');
    const React = window.React;
    const ReactDOM = window.ReactDOM;
    
    if (!React || !ReactDOM) {
      console.error('React or ReactDOM not available');
      initializeFallbackApp();
      return;
    }
    
    // Simple Gmail email organizer component
    const GmailOrganizer = () => {
      const [emails, setEmails] = React.useState([]);
      const [loading, setLoading] = React.useState(true);
      
      React.useEffect(() => {
        loadGmailEmails();
        
        // Listen for messages from content script
        const messageListener = (event) => {
          if (event.data && event.data.type === 'GMAIL_EMAILS_UPDATE') {
            console.log('Received emails update:', event.data.emails.length);
            setEmails(event.data.emails);
            setLoading(false);
          }
        };
        
        window.addEventListener('message', messageListener);
        
        // Auto-refresh emails periodically
        const interval = setInterval(loadGmailEmails, 10000);
        
        return () => {
          window.removeEventListener('message', messageListener);
          clearInterval(interval);
        };
      }, []);
      
      const loadGmailEmails = () => {
        // Request emails from Gmail
        window.postMessage({ type: 'REQUEST_GMAIL_EMAILS' }, '*');
      };
      
      const handleEmailClick = (email) => {
        try {
          // Scroll to email in Gmail interface
          if (email.gmailElement && email.gmailElement.scrollIntoView) {
            email.gmailElement.scrollIntoView({ behavior: 'smooth' });
            setTimeout(() => {
              if (email.gmailElement.click) {
                email.gmailElement.click();
              }
            }, 300);
          }
        } catch (error) {
          console.error('Error clicking email:', error);
        }
      };
      
      if (loading) {
        return React.createElement('div', {
          style: { 
            padding: '20px', 
            textAlign: 'center',
            color: '#666'
          }
        }, 'Loading Gmail emails...');
      }
      
      if (emails.length === 0) {
        return React.createElement('div', {
          style: { 
            padding: '20px', 
            textAlign: 'center',
            color: '#666'
          }
        }, 'No emails found. Try refreshing Gmail.');
      }
      
      return React.createElement('div', {
        style: {
          padding: '10px',
          height: '100%',
          overflow: 'auto',
          fontFamily: 'Arial, sans-serif',
          fontSize: '14px'
        }
      }, [
        React.createElement('div', { 
          key: 'header',
          style: { 
            padding: '10px 0',
            borderBottom: '1px solid #eee',
            marginBottom: '10px'
          }
        }, [
          React.createElement('h3', { 
            key: 'title',
            style: { margin: '0 0 5px 0', fontSize: '16px' }
          }, 'Email Organizer'),
          React.createElement('div', { 
            key: 'stats',
            style: { color: '#666', fontSize: '12px' }
          }, `${emails.length} emails found`)
        ]),
        React.createElement('div', {
          key: 'emails',
          style: { height: 'calc(100% - 80px)', overflow: 'auto' }
        }, emails.map((email, index) => 
          React.createElement('div', {
            key: `email-${index}`,
            onClick: () => handleEmailClick(email),
            style: {
              padding: '12px 8px',
              borderBottom: '1px solid #f0f0f0',
              cursor: 'pointer',
              fontSize: '12px',
              transition: 'background-color 0.2s',
              ':hover': { backgroundColor: '#f5f5f5' }
            },
            onMouseEnter: (e) => e.target.style.backgroundColor = '#f5f5f5',
            onMouseLeave: (e) => e.target.style.backgroundColor = 'transparent'
          }, [
            React.createElement('div', {
              key: 'subject',
              style: { 
                fontWeight: 'bold', 
                marginBottom: '4px',
                fontSize: '13px',
                lineHeight: '1.3'
              }
            }, email.subject || 'No Subject'),
            React.createElement('div', {
              key: 'from',
              style: { 
                color: '#666',
                fontSize: '11px',
                marginBottom: '2px'
              }
            }, email.from || 'Unknown Sender'),
            React.createElement('div', {
              key: 'date',
              style: { 
                color: '#999',
                fontSize: '10px'
              }
            }, email.date ? new Date(email.date).toLocaleDateString() : '')
          ])
        ))
      ]);
    };
    
    // Render the app
    const container = document.getElementById('gmail-organizer-root');
    if (container) {
      console.log('Rendering React app to container');
      const root = ReactDOM.createRoot(container);
      root.render(React.createElement(GmailOrganizer));
    } else {
      console.error('Gmail organizer root container not found');
    }
  } catch (error) {
    console.error('Error initializing React app:', error);
    initializeFallbackApp();
  }
}

function initializeFallbackApp() {
  console.log('Initializing fallback app...');
  const container = document.getElementById('gmail-organizer-root');
  if (container) {
    container.innerHTML = `
      <div style="padding: 20px; font-family: Arial, sans-serif;">
        <h3 style="margin: 0 0 10px 0;">Gmail Email Organizer</h3>
        <p style="color: #666; font-size: 14px;">Extension loaded successfully!</p>
        <p style="color: #666; font-size: 12px;">React components failed to load, but basic functionality is available.</p>
        <button onclick="window.location.reload()" style="
          padding: 8px 16px;
          background: #1a73e8;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 12px;
        ">Refresh Gmail</button>
      </div>
    `;
  }
}

// Make Gmail email extraction available to the app
window.gmailOrganizer = {
  getGmailEmails: function() {
    const emails = [];
    
    try {
      // Extract emails from Gmail interface
      const emailElements = document.querySelectorAll('tr[id]:not([id=""]), [data-legacy-thread-id]');
      
      emailElements.forEach((element, index) => {
        try {
          const subjectElement = element.querySelector('[data-subject]') || 
                                element.querySelector('.bog') ||
                                element.querySelector('span[id^=":]');
          
          const senderElement = element.querySelector('[email]') ||
                               element.querySelector('.yW span') ||
                               element.querySelector('.go span');
          
          const dateElement = element.querySelector('.xY span') ||
                             element.querySelector('[title*="GMT"]');

          const isUnread = element.classList.contains('zE');
          const isStarred = element.querySelector('.T-KT')?.classList?.contains('T-KT-Jp');

          const email = {
            id: `gmail-${index}`,
            subject: subjectElement?.textContent?.trim() || 'No Subject',
            from: senderElement?.textContent?.trim() || 'Unknown Sender',
            to: 'me@gmail.com',
            body: 'Click to view in Gmail',
            date: new Date(),
            isRead: !isUnread,
            isStarred: !!isStarred,
            folder: 'inbox',
            labels: [],
            gmailElement: element
          };
          
          emails.push(email);
        } catch (error) {
          console.warn('Failed to parse email element:', error);
        }
      });
    } catch (error) {
      console.error('Failed to extract Gmail emails:', error);
    }
    
    return emails.slice(0, 20); // Limit for performance
  }
};

// Listen for requests from the React app
window.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'REQUEST_GMAIL_EMAILS') {
    const emails = window.gmailOrganizer.getGmailEmails();
    window.postMessage({ type: 'GMAIL_EMAILS_UPDATE', emails }, '*');
  }
});