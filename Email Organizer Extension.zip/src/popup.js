// Gmail Email Organizer Popup Script

document.addEventListener('DOMContentLoaded', () => {
  const toggleButton = document.getElementById('toggleSidebar');
  const openGmailButton = document.getElementById('openGmail');
  const settingsButton = document.getElementById('settings');
  const statusDiv = document.getElementById('status');

  // Check if current tab is Gmail
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    
    if (currentTab.url && currentTab.url.includes('mail.google.com')) {
      statusDiv.textContent = 'Gmail tab detected ✓';
      statusDiv.className = 'status';
      toggleButton.disabled = false;
      toggleButton.textContent = 'Toggle Email Organizer';
    } else {
      statusDiv.textContent = 'Please open Gmail first';
      statusDiv.className = 'status error';
      toggleButton.disabled = true;
    }
  });

  // Toggle sidebar
  toggleButton.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      // Set a timeout for the message
      const timeoutId = setTimeout(() => {
        statusDiv.textContent = 'Please refresh Gmail page';
        statusDiv.className = 'status error';
      }, 3000);

      chrome.tabs.sendMessage(tabs[0].id, { action: 'toggleSidebar' }, (response) => {
        clearTimeout(timeoutId);
        
        if (chrome.runtime.lastError) {
          statusDiv.textContent = 'Please refresh Gmail page';
          statusDiv.className = 'status error';
        } else if (response && response.success) {
          window.close();
        } else {
          statusDiv.textContent = 'Extension not ready, please try again';
          statusDiv.className = 'status error';
        }
      });
    });
  });

  // Open Gmail
  openGmailButton.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://mail.google.com' });
  });

  // Settings (future feature)
  settingsButton.addEventListener('click', () => {
    // For now, just show an alert
    alert('Settings feature coming soon! You can customize folders and filters directly in the extension sidebar.');
  });
});