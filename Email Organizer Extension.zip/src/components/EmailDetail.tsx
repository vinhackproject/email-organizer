import { Email } from '../types/email';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { 
  Reply, 
  ReplyAll, 
  Forward, 
  Star, 
  Archive, 
  Trash2, 
  Paperclip,
  Download
} from 'lucide-react';
import { cn } from './ui/utils';

interface EmailDetailProps {
  email: Email | null;
  onAction: (emailId: string, action: 'read' | 'unread' | 'star' | 'unstar' | 'delete' | 'archive') => void;
}

export function EmailDetail({ email, onAction }: EmailDetailProps) {
  if (!email) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <p>Select an email to read</p>
          <p className="mt-1">Choose an email from the list to view its contents</p>
        </div>
      </div>
    );
  }

  const formatFullDate = (date: Date) => {
    return date.toLocaleString([], {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleStarClick = () => {
    onAction(email.id, email.isStarred ? 'unstar' : 'star');
  };

  const handleArchiveClick = () => {
    onAction(email.id, 'archive');
  };

  const handleDeleteClick = () => {
    onAction(email.id, 'delete');
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 min-w-0">
            <h1 className="mb-2">{email.subject}</h1>
            <div className="flex items-center gap-2 text-muted-foreground">
              <span>From: {email.from}</span>
              <span>•</span>
              <span>To: {email.to}</span>
            </div>
            <p className="text-muted-foreground mt-1">
              {formatFullDate(email.date)}
            </p>
          </div>
          
          <div className="flex items-center gap-1 ml-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleStarClick}
            >
              <Star 
                className={cn(
                  "w-4 h-4",
                  email.isStarred ? "fill-yellow-400 text-yellow-400" : ""
                )}
              />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleArchiveClick}>
              <Archive className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleDeleteClick}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        {email.labels.length > 0 && (
          <div className="flex gap-2 mb-4">
            {email.labels.map((label) => (
              <Badge key={label} variant="secondary">
                {label}
              </Badge>
            ))}
          </div>
        )}
        
        {email.attachments && email.attachments.length > 0 && (
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Paperclip className="w-4 h-4" />
              <span>{email.attachments.length} attachment{email.attachments.length > 1 ? 's' : ''}</span>
            </div>
            <div className="flex gap-2">
              {email.attachments.map((attachment, index) => (
                <Button key={index} variant="outline" size="sm" className="gap-2">
                  <Download className="w-3 h-3" />
                  {attachment}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-4">
        <div className="prose prose-sm max-w-none">
          {email.body.split('\n').map((paragraph, index) => (
            <p key={index} className="mb-4 last:mb-0">
              {paragraph}
            </p>
          ))}
        </div>
      </ScrollArea>

      {/* Actions */}
      <div className="p-4 border-t border-border">
        <div className="flex gap-2">
          <Button>
            <Reply className="w-4 h-4 mr-2" />
            Reply
          </Button>
          <Button variant="outline">
            <ReplyAll className="w-4 h-4 mr-2" />
            Reply All
          </Button>
          <Button variant="outline">
            <Forward className="w-4 h-4 mr-2" />
            Forward
          </Button>
        </div>
      </div>
    </div>
  );
}