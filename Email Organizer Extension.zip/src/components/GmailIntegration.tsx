import { useState, useEffect } from 'react';
import { Email } from '../types/email';

interface GmailIntegrationProps {
  onEmailsLoaded: (emails: Email[]) => void;
}

export function GmailIntegration({ onEmailsLoaded }: GmailIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if we're in Gmail context
    checkGmailConnection();
    
    // Set up periodic email refresh
    const interval = setInterval(() => {
      if (isConnected) {
        loadGmailEmails();
      }
    }, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval);
  }, [isConnected]);

  const checkGmailConnection = () => {
    try {
      // Check if we're in Gmail and if chrome extension APIs are available
      const isGmail = window.location.hostname.includes('mail.google.com');
      const isExtension = !!(window.chrome && chrome.runtime && chrome.runtime.id);
      const hasGmailOrganizer = !!(window.gmailOrganizer);
      
      setIsConnected(isGmail && (isExtension || hasGmailOrganizer));
      
      if (isGmail && (isExtension || hasGmailOrganizer)) {
        loadGmailEmails();
      }
    } catch (error) {
      console.error('Failed to check Gmail connection:', error);
      setIsConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const loadGmailEmails = async () => {
    try {
      // Get emails from Gmail DOM
      const emails = await extractGmailEmails();
      if (emails && emails.length > 0) {
        onEmailsLoaded(emails);
      }
    } catch (error) {
      console.error('Failed to load Gmail emails:', error);
      // Fallback to empty array to prevent infinite loading
      onEmailsLoaded([]);
    }
  };

  const extractGmailEmails = async (): Promise<Email[]> => {
    return new Promise((resolve) => {
      // Use the Gmail extraction logic from content script
      if (window.gmailOrganizer?.getGmailEmails) {
        const emails = window.gmailOrganizer.getGmailEmails();
        resolve(emails);
      } else {
        // Fallback to DOM parsing
        const emails = parseEmailsFromDOM();
        resolve(emails);
      }
    });
  };

  const parseEmailsFromDOM = (): Email[] => {
    const emails: Email[] = [];
    
    try {
      // Look for Gmail email rows
      const emailRows = document.querySelectorAll('tr[id]:not([id=""]), [data-legacy-thread-id]');
      
      emailRows.forEach((row, index) => {
        const email = parseEmailRow(row as HTMLElement, index);
        if (email) {
          emails.push(email);
        }
      });
    } catch (error) {
      console.error('Error parsing emails from DOM:', error);
    }
    
    return emails.slice(0, 50); // Limit to 50 emails for performance
  };

  const parseEmailRow = (row: HTMLElement, index: number): Email | null => {
    try {
      // Extract subject
      const subjectElement = row.querySelector('[data-subject]') || 
                           row.querySelector('.bog') ||
                           row.querySelector('span[id^=":]');
      const subject = subjectElement?.textContent?.trim() || 'No Subject';

      // Extract sender
      const senderElement = row.querySelector('[email]') ||
                          row.querySelector('.yW span') ||
                          row.querySelector('.go span');
      const from = senderElement?.textContent?.trim() || 'Unknown Sender';

      // Extract date
      const dateElement = row.querySelector('.xY span') ||
                         row.querySelector('[title*="GMT"]');
      const dateText = dateElement?.textContent || dateElement?.getAttribute('title') || '';
      const date = parseGmailDate(dateText);

      // Check read status
      const isUnread = row.classList.contains('zE') || 
                      row.querySelector('.yW')?.style?.fontWeight === 'bold';

      // Check starred status
      const isStarred = row.querySelector('.T-KT')?.classList?.contains('T-KT-Jp') ||
                       !!row.querySelector('[data-tooltip="Starred"]');

      // Extract labels
      const labels = extractLabelsFromRow(row);

      // Get a preview of the email content
      const previewElement = row.querySelector('.y2');
      const bodyPreview = previewElement?.textContent?.trim() || 'Click to view email content';

      return {
        id: `gmail-${index}-${Date.now()}`,
        subject,
        from,
        to: 'me@gmail.com',
        body: bodyPreview,
        date,
        isRead: !isUnread,
        isStarred: !!isStarred,
        folder: 'inbox',
        labels,
        attachments: hasAttachments(row) ? ['attachment'] : undefined
      };
    } catch (error) {
      console.error('Error parsing email row:', error);
      return null;
    }
  };

  const parseGmailDate = (dateString: string): Date => {
    if (!dateString) return new Date();
    
    // Handle GMT format
    if (dateString.includes('GMT')) {
      return new Date(dateString);
    }
    
    // Handle time format (today)
    if (dateString.match(/^\d{1,2}:\d{2}/)) {
      const today = new Date();
      const [hours, minutes] = dateString.split(':').map(Number);
      today.setHours(hours, minutes, 0, 0);
      return today;
    }
    
    // Handle short date format (this year)
    if (dateString.match(/^\w{3} \d{1,2}$/)) {
      const currentYear = new Date().getFullYear();
      return new Date(`${dateString}, ${currentYear}`);
    }
    
    return new Date(dateString) || new Date();
  };

  const extractLabelsFromRow = (row: HTMLElement): string[] => {
    const labels: string[] = [];
    
    // Look for Gmail labels
    const labelElements = row.querySelectorAll('.at');
    labelElements.forEach(label => {
      const labelText = label.textContent?.trim();
      if (labelText) {
        labels.push(labelText.toLowerCase());
      }
    });

    // Check for importance
    if (row.querySelector('.zE .yW .cL')) {
      labels.push('important');
    }

    return labels;
  };

  const hasAttachments = (row: HTMLElement): boolean => {
    return !!row.querySelector('[alt="Attachment"]') || 
           !!row.querySelector('.aZo');
  };

  if (loading) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <p>Connecting to Gmail...</p>
      </div>
    );
  }

  if (!isConnected) {
    return (
      <div className="p-4 text-center">
        <p className="text-muted-foreground mb-4">
          Please open Gmail to use the Email Organizer
        </p>
        <button 
          onClick={() => window.open('https://mail.google.com', '_blank')}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Open Gmail
        </button>
      </div>
    );
  }

  return null; // Component is invisible when working properly
}

// Extend window type for TypeScript
declare global {
  interface Window {
    gmailOrganizer?: {
      getGmailEmails: () => Email[];
    };
  }
}