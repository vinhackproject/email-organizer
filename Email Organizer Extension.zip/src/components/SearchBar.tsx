import { useState } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Search, Filter, X } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onFilterToggle: () => void;
  showFilters: boolean;
}

export function SearchBar({ searchQuery, onSearchChange, onFilterToggle, showFilters }: SearchBarProps) {
  const [localQuery, setLocalQuery] = useState(searchQuery);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(localQuery);
  };

  const handleClear = () => {
    setLocalQuery('');
    onSearchChange('');
  };

  return (
    <div className="p-4 border-b border-border bg-background">
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search emails..."
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            className="pl-10 pr-10"
          />
          {localQuery && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 p-1 h-auto"
              onClick={handleClear}
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
        <Button type="submit" variant="outline">
          Search
        </Button>
        <Button 
          type="button" 
          variant={showFilters ? "default" : "outline"}
          onClick={onFilterToggle}
        >
          <Filter className="w-4 h-4" />
        </Button>
      </form>
      
      {showFilters && (
        <div className="mt-4 p-4 bg-muted rounded-md">
          <h4 className="mb-3">Filters</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block mb-1">Status</label>
              <select className="w-full p-2 border border-border rounded-md">
                <option value="">All</option>
                <option value="unread">Unread</option>
                <option value="read">Read</option>
                <option value="starred">Starred</option>
              </select>
            </div>
            <div>
              <label className="block mb-1">Date Range</label>
              <select className="w-full p-2 border border-border rounded-md">
                <option value="">All time</option>
                <option value="today">Today</option>
                <option value="week">This week</option>
                <option value="month">This month</option>
              </select>
            </div>
            <div>
              <label className="block mb-1">Has Attachments</label>
              <select className="w-full p-2 border border-border rounded-md">
                <option value="">All</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}