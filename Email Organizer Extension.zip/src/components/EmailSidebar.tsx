import { Folder } from '../types/email';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Inbox, 
  Star, 
  Send, 
  FileText, 
  Archive, 
  Shield, 
  Trash2, 
  Briefcase, 
  User, 
  DollarSign,
  Plus
} from 'lucide-react';

interface EmailSidebarProps {
  folders: Folder[];
  activeFolder: string;
  onFolderSelect: (folderId: string) => void;
}

const iconMap = {
  inbox: Inbox,
  star: Star,
  send: Send,
  'file-text': FileText,
  archive: Archive,
  shield: Shield,
  'trash-2': Trash2,
  briefcase: Briefcase,
  user: User,
  'dollar-sign': DollarSign,
};

const colorMap = {
  blue: 'bg-blue-100 text-blue-700',
  green: 'bg-green-100 text-green-700',
  yellow: 'bg-yellow-100 text-yellow-700',
};

export function EmailSidebar({ folders, activeFolder, onFolderSelect }: EmailSidebarProps) {
  return (
    <div className="w-64 bg-card border-r border-border p-4 flex flex-col h-full">
      <div className="mb-6">
        <Button className="w-full">
          <Plus className="w-4 h-4 mr-2" />
          Compose
        </Button>
      </div>

      <div className="space-y-1 flex-1">
        <div className="mb-4">
          <h3 className="px-2 mb-2 text-muted-foreground">Main</h3>
          {folders.slice(0, 7).map((folder) => {
            const IconComponent = iconMap[folder.icon as keyof typeof iconMap];
            const isActive = activeFolder === folder.id;
            
            return (
              <Button
                key={folder.id}
                variant={isActive ? "secondary" : "ghost"}
                className="w-full justify-start px-2 py-2 h-auto"
                onClick={() => onFolderSelect(folder.id)}
              >
                <IconComponent className="w-4 h-4 mr-3 flex-shrink-0" />
                <span className="flex-1 text-left">{folder.name}</span>
                {folder.count > 0 && (
                  <Badge variant="secondary" className="ml-auto">
                    {folder.count}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>

        <div>
          <h3 className="px-2 mb-2 text-muted-foreground">Labels</h3>
          {folders.slice(7).map((folder) => {
            const IconComponent = iconMap[folder.icon as keyof typeof iconMap];
            const isActive = activeFolder === folder.id;
            const colorClass = folder.color ? colorMap[folder.color as keyof typeof colorMap] : '';
            
            return (
              <Button
                key={folder.id}
                variant={isActive ? "secondary" : "ghost"}
                className="w-full justify-start px-2 py-2 h-auto"
                onClick={() => onFolderSelect(folder.id)}
              >
                <div className={`w-3 h-3 rounded-full mr-3 flex-shrink-0 ${colorClass || 'bg-muted'}`} />
                <span className="flex-1 text-left">{folder.name}</span>
                {folder.count > 0 && (
                  <Badge variant="secondary" className="ml-auto">
                    {folder.count}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}