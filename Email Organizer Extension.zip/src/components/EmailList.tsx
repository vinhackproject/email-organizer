import { Email } from '../types/email';
import { EmailItem } from './EmailItem';
import { ScrollArea } from './ui/scroll-area';

interface EmailListProps {
  emails: Email[];
  selectedEmailId: string | null;
  onEmailSelect: (email: Email) => void;
  onEmailAction: (emailId: string, action: 'read' | 'unread' | 'star' | 'unstar' | 'delete' | 'archive') => void;
}

export function EmailList({ emails, selectedEmailId, onEmailSelect, onEmailAction }: EmailListProps) {
  if (emails.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <p>No emails in this folder</p>
          <p className="mt-1">Your emails will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 border-r border-border">
      <ScrollArea className="h-full">
        <div className="divide-y divide-border">
          {emails.map((email) => (
            <EmailItem
              key={email.id}
              email={email}
              isSelected={selectedEmailId === email.id}
              onClick={() => onEmailSelect(email)}
              onAction={onEmailAction}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}