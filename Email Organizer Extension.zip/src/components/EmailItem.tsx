import { Email } from '../types/email';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Star, Paperclip, Archive, Trash2 } from 'lucide-react';
import { cn } from './ui/utils';

interface EmailItemProps {
  email: Email;
  isSelected: boolean;
  onClick: () => void;
  onAction: (emailId: string, action: 'read' | 'unread' | 'star' | 'unstar' | 'delete' | 'archive') => void;
}

export function EmailItem({ email, isSelected, onClick, onAction }: EmailItemProps) {
  const formatDate = (date: Date) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const emailDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    
    if (emailDate.getTime() === today.getTime()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (emailDate.getTime() === today.getTime() - 86400000) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const handleStarClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAction(email.id, email.isStarred ? 'unstar' : 'star');
  };

  const handleArchiveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAction(email.id, 'archive');
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAction(email.id, 'delete');
  };

  return (
    <div
      className={cn(
        "p-4 hover:bg-accent/50 cursor-pointer transition-colors group",
        isSelected && "bg-accent",
        !email.isRead && "bg-blue-50/50 border-l-2 border-l-blue-500"
      )}
      onClick={onClick}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <Button
            variant="ghost"
            size="sm"
            className="p-0 h-auto hover:bg-transparent"
            onClick={handleStarClick}
          >
            <Star 
              className={cn(
                "w-4 h-4",
                email.isStarred ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground hover:text-yellow-400"
              )}
            />
          </Button>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <span className={cn(
                "truncate",
                !email.isRead && "font-semibold"
              )}>
                {email.from}
              </span>
              <div className="flex items-center gap-2 ml-2">
                {email.attachments && email.attachments.length > 0 && (
                  <Paperclip className="w-3 h-3 text-muted-foreground" />
                )}
                <span className="text-muted-foreground whitespace-nowrap">
                  {formatDate(email.date)}
                </span>
              </div>
            </div>
            
            <h4 className={cn(
              "truncate mb-1",
              !email.isRead && "font-semibold"
            )}>
              {email.subject}
            </h4>
            
            <p className="text-muted-foreground truncate">
              {email.body.split('\n')[0]}
            </p>
            
            {email.labels.length > 0 && (
              <div className="flex gap-1 mt-2">
                {email.labels.slice(0, 3).map((label) => (
                  <Badge key={label} variant="secondary" className="text-xs">
                    {label}
                  </Badge>
                ))}
                {email.labels.length > 3 && (
                  <Badge variant="secondary" className="text-xs">
                    +{email.labels.length - 3}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="sm"
            className="p-1 h-auto"
            onClick={handleArchiveClick}
          >
            <Archive className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="p-1 h-auto"
            onClick={handleDeleteClick}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}