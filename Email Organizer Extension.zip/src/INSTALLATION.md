# Gmail Email Organizer - Installation Guide

## Quick Fix for Timeout Errors

If you're experiencing timeout errors, follow these steps:

### 1. Check Extension Files
Make sure all these files are present in your extension folder:
- `manifest.json`
- `content.js`
- `background.js`
- `app-bundle.js`
- `extension.css`
- `popup.html`
- `popup.js`

### 2. Load Extension in Chrome

1. **Open Chrome Extensions**:
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)

2. **Remove Old Version** (if exists):
   - Find any existing "Gmail Email Organizer"
   - Click "Remove"

3. **Load New Version**:
   - Click "Load unpacked"
   - Select the folder containing all extension files
   - The extension should load without errors

### 3. Test the Extension

1. **Open Gmail**:
   - Navigate to [mail.google.com](https://mail.google.com)
   - Wait for Gmail to fully load

2. **Look for the Extension**:
   - You should see a blue floating button in the bottom right
   - Click it to open the organizer sidebar

3. **Alternative Access**:
   - Click the extension icon in Chrome's toolbar
   - Click "Toggle Email Organizer" in the popup

### 4. Troubleshooting

#### Extension Icon Not Showing
- Refresh the Gmail page
- Check if extension is enabled in `chrome://extensions/`
- Try opening a new Gmail tab

#### "Please refresh Gmail page" Error
- This is normal on first install
- Simply refresh the Gmail page
- The extension should work after refresh

#### Sidebar Not Opening
- Check browser console for errors (F12 → Console)
- Ensure you're on `mail.google.com` (not Gmail app)
- Try disabling other Gmail extensions temporarily

#### No Emails Showing
- The extension extracts emails from Gmail's interface
- Make sure you have emails in your inbox
- Try switching Gmail views (Inbox, Sent, etc.)

### 5. Advanced Troubleshooting

#### Clear Extension Data
```javascript
// In browser console on Gmail page:
localStorage.clear();
sessionStorage.clear();
location.reload();
```

#### Check Extension Permissions
- Go to `chrome://extensions/`
- Click "Details" on Gmail Email Organizer
- Ensure "Allow on all sites" or add `mail.google.com`

#### Reset Extension
1. Remove extension from Chrome
2. Delete extension folder
3. Re-download/extract extension files
4. Load as unpacked extension again

## Features Once Working

- **Email Organization**: Custom folders and labels
- **Advanced Search**: Filter by content, sender, date
- **Quick Actions**: Archive, delete, star emails
- **Gmail Integration**: Works alongside Gmail interface
- **Real-time Updates**: Syncs with Gmail changes

## Need Help?

If you continue having issues:
1. Check the browser console for specific error messages
2. Ensure you're using a recent version of Chrome
3. Try the extension in an incognito window
4. Disable other extensions to test for conflicts

The extension is designed to work seamlessly with Gmail's interface while providing powerful organization tools.