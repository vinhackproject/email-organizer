export interface Email {
  id: string;
  from: string;
  to: string;
  subject: string;
  body: string;
  date: Date;
  isRead: boolean;
  isStarred: boolean;
  folder: string;
  labels: string[];
  attachments?: string[];
}

export interface Folder {
  id: string;
  name: string;
  count: number;
  icon: string;
  color?: string;
}