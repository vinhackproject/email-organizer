// Gmail Email Organizer Background Script

chrome.runtime.onInstalled.addListener(() => {
  console.log('Gmail Email Organizer installed');
});

// Handle extension icon click
chrome.action.onClicked.addListener(async (tab) => {
  try {
    // Send message to content script to toggle sidebar
    await chrome.tabs.sendMessage(tab.id, { action: 'toggleSidebar' });
  } catch (error) {
    console.error('Failed to send message to content script:', error);
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  try {
    if (request.action === 'getEmails') {
      // Handle email data requests
      sendResponse({ success: true });
      return true;
    }
    
    if (request.action === 'saveSettings') {
      // Save user settings
      chrome.storage.sync.set(request.settings, () => {
        sendResponse({ success: true });
      });
      return true; // Keep message channel open for async response
    }
    
    if (request.action === 'getSettings') {
      // Retrieve user settings
      chrome.storage.sync.get(null, (settings) => {
        sendResponse({ settings });
      });
      return true;
    }
  } catch (error) {
    console.error('Error handling message:', error);
    sendResponse({ success: false, error: error.message });
  }
});

// Handle Gmail navigation changes with error handling
if (chrome.webNavigation && chrome.webNavigation.onHistoryStateUpdated) {
  chrome.webNavigation.onHistoryStateUpdated.addListener(async (details) => {
    if (details.url.includes('mail.google.com')) {
      try {
        // Notify content script of navigation change
        await chrome.tabs.sendMessage(details.tabId, { action: 'navigationChanged' });
      } catch (error) {
        console.log('Content script not ready for navigation message');
      }
    }
  }, {
    url: [{ hostContains: 'mail.google.com' }]
  });
}