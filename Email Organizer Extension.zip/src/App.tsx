import { useState, useMemo, useEffect } from 'react';
import { EmailSidebar } from './components/EmailSidebar';
import { EmailList } from './components/EmailList';
import { EmailDetail } from './components/EmailDetail';
import { SearchBar } from './components/SearchBar';
import { GmailIntegration } from './components/GmailIntegration';
import { mockEmails, mockFolders } from './data/mockEmails';
import { Email } from './types/email';

export default function App() {
  const [emails, setEmails] = useState<Email[]>([]);
  const [activeFolder, setActiveFolder] = useState('inbox');
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [isGmailMode, setIsGmailMode] = useState(false);

  // Check if we're running as a browser extension in Gmail
  useEffect(() => {
    const checkExtensionMode = () => {
      const isInGmail = window.location.hostname.includes('mail.google.com');
      const isExtension = !!(window.chrome && chrome.runtime && chrome.runtime.id);
      
      setIsGmailMode(isInGmail && isExtension);
      
      // If not in Gmail mode, use mock data
      if (!isInGmail || !isExtension) {
        setEmails(mockEmails);
      }
    };

    checkExtensionMode();
  }, []);

  // Filter emails based on active folder and search query
  const filteredEmails = useMemo(() => {
    let filtered = emails;

    // Filter by folder
    if (activeFolder === 'starred') {
      filtered = filtered.filter(email => email.isStarred);
    } else if (activeFolder !== 'inbox') {
      filtered = filtered.filter(email => 
        email.folder === activeFolder || 
        email.labels.includes(activeFolder)
      );
    } else {
      filtered = filtered.filter(email => email.folder === 'inbox');
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(email =>
        email.subject.toLowerCase().includes(query) ||
        email.from.toLowerCase().includes(query) ||
        email.body.toLowerCase().includes(query) ||
        email.labels.some(label => label.toLowerCase().includes(query))
      );
    }

    // Sort by date (newest first)
    return filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [emails, activeFolder, searchQuery]);

  // Update folder counts
  const foldersWithCounts = useMemo(() => {
    return mockFolders.map(folder => {
      let count = 0;
      
      if (folder.id === 'inbox') {
        count = emails.filter(email => email.folder === 'inbox').length;
      } else if (folder.id === 'starred') {
        count = emails.filter(email => email.isStarred).length;
      } else if (folder.id === 'sent') {
        count = emails.filter(email => email.folder === 'sent').length;
      } else if (folder.id === 'drafts') {
        count = emails.filter(email => email.folder === 'drafts').length;
      } else if (folder.id === 'archive') {
        count = emails.filter(email => email.folder === 'archive').length;
      } else if (folder.id === 'spam') {
        count = emails.filter(email => email.folder === 'spam').length;
      } else if (folder.id === 'trash') {
        count = emails.filter(email => email.folder === 'trash').length;
      } else {
        // Custom labels
        count = emails.filter(email => email.labels.includes(folder.id)).length;
      }

      return { ...folder, count };
    });
  }, [emails]);

  const handleEmailAction = (emailId: string, action: 'read' | 'unread' | 'star' | 'unstar' | 'delete' | 'archive') => {
    setEmails(prevEmails => 
      prevEmails.map(email => {
        if (email.id === emailId) {
          switch (action) {
            case 'read':
              return { ...email, isRead: true };
            case 'unread':
              return { ...email, isRead: false };
            case 'star':
              return { ...email, isStarred: true };
            case 'unstar':
              return { ...email, isStarred: false };
            case 'archive':
              return { ...email, folder: 'archive' };
            case 'delete':
              return { ...email, folder: 'trash' };
            default:
              return email;
          }
        }
        return email;
      })
    );

    // If the current email was moved and is selected, deselect it
    if (selectedEmail?.id === emailId && (action === 'archive' || action === 'delete')) {
      setSelectedEmail(null);
    }
  };

  const handleEmailSelect = (email: Email) => {
    setSelectedEmail(email);
    // Mark as read when opened
    if (!email.isRead) {
      handleEmailAction(email.id, 'read');
    }
  };

  const handleFolderSelect = (folderId: string) => {
    setActiveFolder(folderId);
    setSelectedEmail(null);
    setSearchQuery('');
  };

  const handleGmailEmailsLoaded = (gmailEmails: Email[]) => {
    setEmails(gmailEmails);
  };

  return (
    <div className="h-screen flex flex-col bg-background gmail-organizer-app">
      {isGmailMode && (
        <GmailIntegration onEmailsLoaded={handleGmailEmailsLoaded} />
      )}
      
      <SearchBar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onFilterToggle={() => setShowFilters(!showFilters)}
        showFilters={showFilters}
      />
      
      <div className="flex-1 flex overflow-hidden">
        <EmailSidebar
          folders={foldersWithCounts}
          activeFolder={activeFolder}
          onFolderSelect={handleFolderSelect}
        />
        
        <EmailList
          emails={filteredEmails}
          selectedEmailId={selectedEmail?.id || null}
          onEmailSelect={handleEmailSelect}
          onEmailAction={handleEmailAction}
        />
        
        <EmailDetail
          email={selectedEmail}
          onAction={handleEmailAction}
        />
      </div>
      
      {!isGmailMode && emails.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80">
          <div className="text-center">
            <h2 className="mb-2">Gmail Email Organizer</h2>
            <p className="text-muted-foreground mb-4">
              Install as a browser extension to organize your Gmail emails
            </p>
            <p className="text-muted-foreground">
              Currently showing demo mode
            </p>
          </div>
        </div>
      )}
    </div>
  );
}