// Gmail Email Organizer Content Script
class GmailOrganizer {
  constructor() {
    this.isActive = false;
    this.sidebarContainer = null;
    this.isInitialized = false;
    this.init();
  }

  init() {
    // Prevent multiple initializations
    if (this.isInitialized) return;
    this.isInitialized = true;
    
    // Wait for Gmail to load
    this.waitForGmail(() => {
      this.createSidebar();
      this.injectReactApp();
      this.setupToggleButton();
      this.setupMessageListeners();
    });
  }

  waitForGmail(callback) {
    const checkGmail = () => {
      // Check if Gmail interface is loaded
      const gmailContainer = document.querySelector('[role="main"]') || 
                           document.querySelector('.nH') ||
                           document.querySelector('#gmail-content');
      
      if (gmailContainer) {
        callback();
      } else {
        setTimeout(checkGmail, 1000);
      }
    };
    checkGmail();
  }

  createSidebar() {
    // Create sidebar container
    this.sidebarContainer = document.createElement('div');
    this.sidebarContainer.id = 'gmail-organizer-sidebar';
    this.sidebarContainer.className = 'gmail-organizer-hidden';
    
    // Create React root container
    const reactRoot = document.createElement('div');
    reactRoot.id = 'gmail-organizer-root';
    this.sidebarContainer.appendChild(reactRoot);

    // Add close button
    const closeButton = document.createElement('button');
    closeButton.innerHTML = '×';
    closeButton.className = 'gmail-organizer-close';
    closeButton.onclick = () => this.toggleSidebar();
    this.sidebarContainer.appendChild(closeButton);

    document.body.appendChild(this.sidebarContainer);
  }

  setupToggleButton() {
    // Create floating toggle button
    const toggleButton = document.createElement('button');
    toggleButton.id = 'gmail-organizer-toggle';
    toggleButton.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
        <polyline points="22,6 12,13 2,6"></polyline>
      </svg>
    `;
    toggleButton.title = 'Toggle Email Organizer';
    toggleButton.onclick = () => this.toggleSidebar();
    
    document.body.appendChild(toggleButton);
  }

  toggleSidebar() {
    this.isActive = !this.isActive;
    if (this.isActive) {
      this.sidebarContainer.classList.remove('gmail-organizer-hidden');
      this.sidebarContainer.classList.add('gmail-organizer-visible');
      document.body.classList.add('gmail-organizer-active');
    } else {
      this.sidebarContainer.classList.remove('gmail-organizer-visible');
      this.sidebarContainer.classList.add('gmail-organizer-hidden');
      document.body.classList.remove('gmail-organizer-active');
    }
  }

  injectReactApp() {
    // Create script to load React app
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('app-bundle.js');
    script.onload = () => {
      // Initialize React app in the sidebar
      setTimeout(() => {
        if (window.initGmailOrganizer) {
          window.initGmailOrganizer();
        }
      }, 100);
    };
    script.onerror = (error) => {
      console.error('Failed to load app bundle:', error);
    };
    document.head.appendChild(script);
  }

  setupMessageListeners() {
    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      try {
        if (request.action === 'toggleSidebar') {
          this.toggleSidebar();
          sendResponse({ success: true });
        } else if (request.action === 'navigationChanged') {
          // Handle Gmail navigation changes
          setTimeout(() => {
            this.refreshEmails();
          }, 1000);
          sendResponse({ success: true });
        }
      } catch (error) {
        console.error('Error handling message:', error);
        sendResponse({ success: false, error: error.message });
      }
      return true;
    });
  }

  refreshEmails() {
    // Trigger email refresh in the React app
    if (window.gmailOrganizer) {
      const emails = window.gmailOrganizer.getGmailEmails();
      window.postMessage({ type: 'GMAIL_EMAILS_UPDATE', emails }, '*');
    }
  }

  // Gmail API helpers
  getGmailEmails() {
    // Extract emails from Gmail DOM
    const emailElements = document.querySelectorAll('[data-legacy-thread-id], tr.zA');
    const emails = [];

    emailElements.forEach((element, index) => {
      try {
        const email = this.parseEmailFromElement(element, index);
        if (email) emails.push(email);
      } catch (error) {
        console.warn('Failed to parse email element:', error);
      }
    });

    return emails;
  }

  parseEmailFromElement(element, index) {
    // Parse email data from Gmail DOM element
    const subjectElement = element.querySelector('[data-subject]') || 
                          element.querySelector('.bog') ||
                          element.querySelector('span[id^=":]');
    
    const senderElement = element.querySelector('[email]') ||
                         element.querySelector('.yW span') ||
                         element.querySelector('.go span');
    
    const dateElement = element.querySelector('.xY span') ||
                       element.querySelector('[title*="GMT"]') ||
                       element.querySelector('.xY');

    const isUnread = element.classList.contains('zE') || 
                    element.querySelector('.yW')?.style?.fontWeight === 'bold';
    
    const isStarred = element.querySelector('.T-KT')?.classList?.contains('T-KT-Jp') ||
                     element.querySelector('[data-tooltip="Starred"]');

    return {
      id: `gmail-${index}`,
      subject: subjectElement?.textContent?.trim() || 'No Subject',
      from: senderElement?.textContent?.trim() || 'Unknown Sender',
      to: 'me@gmail.com',
      body: 'Click to view email content in Gmail',
      date: this.parseGmailDate(dateElement?.textContent || dateElement?.title || ''),
      isRead: !isUnread,
      isStarred: !!isStarred,
      folder: 'inbox',
      labels: this.extractLabels(element),
      gmailElement: element
    };
  }

  parseGmailDate(dateString) {
    if (!dateString) return new Date();
    
    // Handle various Gmail date formats
    if (dateString.includes('GMT')) {
      return new Date(dateString);
    }
    
    // Today format (time only)
    if (dateString.match(/^\d{1,2}:\d{2}/)) {
      const today = new Date();
      const [hours, minutes] = dateString.split(':').map(Number);
      today.setHours(hours, minutes, 0, 0);
      return today;
    }
    
    // This year (Mon DD)
    if (dateString.match(/^\w{3} \d{1,2}$/)) {
      const currentYear = new Date().getFullYear();
      return new Date(`${dateString}, ${currentYear}`);
    }
    
    // Previous years (DD/MM/YY or MM/DD/YY)
    return new Date(dateString) || new Date();
  }

  extractLabels(element) {
    const labels = [];
    
    // Look for Gmail labels
    const labelElements = element.querySelectorAll('.at');
    labelElements.forEach(label => {
      const labelText = label.textContent?.trim();
      if (labelText) labels.push(labelText.toLowerCase());
    });

    // Check for importance markers
    if (element.querySelector('.zE .yW .cL')) {
      labels.push('important');
    }

    return labels;
  }
}

// Global organizer instance
let organizerInstance = null;

// Initialize when DOM is ready
function initializeOrganizer() {
  if (!organizerInstance) {
    organizerInstance = new GmailOrganizer();
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeOrganizer);
} else {
  initializeOrganizer();
}

// Listen for navigation changes in Gmail SPA
let lastUrl = location.href;
const observer = new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    // Reinitialize if needed
    setTimeout(() => {
      if (!document.getElementById('gmail-organizer-sidebar')) {
        organizerInstance = null;
        initializeOrganizer();
      }
    }, 1000);
  }
});

// Start observing with throttling
setTimeout(() => {
  observer.observe(document, { subtree: true, childList: true });
}, 2000);